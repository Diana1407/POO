#include <iostream>
#include <fstream>
using namespace std;


class Matrice
{
private:
    int n;
    int **a;
public:
    ///Constructor de copiere
    Matrice(const Matrice &x)
    {
        n = x.n;
        a = new int *[x.n];
        for(int i=0; i<x.n; i++)
        {
            a[i] = new int[n];
            for(int j=0; j<x.n; j++)
                a[i][j] = x.a[i][j];
        }
    }

    void afis()
    {

        for(int i = 0; i < n; ++i)
        {
            for (int j = 0; j < n; ++j)
                cout << a[i][j]<<" ";
            cout<<endl;
        }
    }
    ///Constructor implicit
    Matrice()
    {
        n = 0;
    }
    ///Constructor pt initializarea matricei cu 0
    Matrice(int _n)
    {
        n = _n;
        a = new int *[n];
        for(int i = 0; i< n; ++i)
            a[i]= new int[n];
        for ( int i = 0; i < n; ++i)
            for ( int j = 0; j < n; ++j)
                a[i][j] = 0;
    }
    ///Constructor cu parametru dimensiunea si matricea
    Matrice(int nn, Matrice x)
    {
        n = nn;
        a = new int *[n];
        for(int i = 0; i< n; ++i)
            a[i]= new int[n];
        for ( int i = 0; i < n; ++i)
            for ( int j = 0; j < n; ++j)
                a[i][j] = x.a[i][j];
    }
    ///Definim operatorul >> de citire de tip friend si ii dam instructiuni mai tarziu in afara clasei(pt ca e friend)
    friend istream& operator >>(istream &in, Matrice &x);

    ///Destructorul care sterge matricea;
    ~Matrice()
    {
        for(int i=0; i<n; i++)
            delete a[i];
    }

    ///Operator de atribuire
    Matrice operator=(Matrice b)
    {
        n = b.n;
        a = new int *[n];
        for(int i=0; i<n; i++)
        {
            a[i] = new int [n];
            for(int j=0; j<n; j++)
                a[i][j] = b.a[i][j];
        }
        return b;
    }

    ///La operatii sa fiu atenta la dimensiunile matricilor
    ///Adunare de Matrici
    Matrice operator+(Matrice b)
    {

        Matrice c(b.n);
        if (!(n == b.n ))
        {
            cout << "Nu au dimensiuni egale";
            return c;
        }

        for(int i=0; i<n; i++)
            for(int j=0; j<n; j++)
                c.a[i][j] = a[i][j] + b.a[i][j];
        return c;

    }


    ///Scadere de matrici
    Matrice operator-(Matrice b)
    {

        Matrice c(b.n);
        if (!(n == b.n))
        {
            cout << "Nu au dimensiuni egale";
            return c;
        }

        for(int i=0; i<n; i++)
            for(int j=0; j<n; j++)
                c.a[i][j] = a[i][j] - b.a[i][j];
        return c;

    }

    bool operator==(Matrice b)
    {
        if(n != b.n )
            return false;
        for(int i=0; i<n; i++)
            for(int j=0; j<n; j++)
                if(a[i][j] != b.a[i][j])
                    return false;
        return true;
    }

    bool operator!=(Matrice b)
    {

        for(int i=0; i<n; i++)
            for(int j=0; j<n; j++)
                if(a[i][j] == b.a[i][j])
                    return false;
        return true;
    }

    ///Inmultire de matrici
    Matrice operator*(Matrice x)
    {

        Matrice p(n);

        for(int i=0; i<n; i++)
            for(int j=0; j<x.n; j++)
                p.a[i][j] = 0;

        if(n != x.n)
        {
            cout<<"imposibil";
            return 0;

        }
        for(int i=0; i<n; i++)
            for(int j =0; j<x.n; j++)
                for(int k=0; k<n; k++)
                    p.a[i][j] = p.a[i][j] + a[i][k] * x.a[k][j];

        return p;
    }


    ///Inmultire cu un scalar
    Matrice operator&(int z)
    {
        Matrice p(n);
        for(int i=0; i<n; i++)
            for(int j =0; j<n; j++)
                p.a[i][j] = z *a[i][j];
        return p;
    }

    ///Ridicare la putere
    Matrice operator^(int z)
    {
        ///Creez o matrice pe care o egalez cu matricea a si dupa le inmultesc intre ele
        Matrice p(n);
        for(int i=0; i<n; i++)
            for(int j=0; j<n; j++)
                p.a[i][j] = a[i][j];

        if(z == 1)
            return *this;
        while(z>1)
        {
            p = p * (*this);
            z--;
        }
        return p;
    }

    int det()
    {
        if(n==2)
            return a[0][0]*a[1][1]-a[0][1]*a[1][0];
        if(n==3)
            return a[0][0]*a[1][1]*a[2][2]+a[1][0]*a[2][1]*a[0][2]+a[2][0]*a[0][1]*a[1][2]-a[0][2]*a[1][1]*a[2][0]-a[1][2]*a[2][1]*a[0][0]-a[2][2]*a[0][1]*a[1][0];
        if(n>3)
        {
            cout<<"nu stim";
            return 0;
        }
    }

    void transpusa()
    {
        ///sa nu uit sa intorc rezultatul in matricea a
        Matrice x(n);
        for(int i=0; i<n; i++)
            for(int j=0; j<n; j++)
            {
                x.a[i][j]=a[j][i];
            }
        for(int i=0; i<n; i++)
            for(int j=0; j<n; j++)
                a[i][j]=x.a[i][j];
    }

    void A_stelat()
    {
        ///??
        ///parcurg matricea si formez una de n-1 si mai fac inca 2 foruri si daca liniile si col difera de cea initiala
        ///bag valorile in matricea de n-1
        ///verific -1 la puterea linie + coloana si pun in matricea x det
        ///sa nu uit sa o intorc in matricea a
        Matrice x(n);
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<n; j++)
            {
                Matrice y(n-1);
                for(int c=0; c<n; c++)
                    for(int z=0; z<n; z++)
                    {
                        if(c!=i && z!=j)
                        {
                            y.a[c][z]=a[i][j];
                        }
                    }
                if((i+j)%2==0)
                    x.a[i][j]=y.det();
                else
                    x.a[i][j]=y.det()*(-1);
            }
        }
        for(int i=0; i<n; i++)
            for(int j=0; j<n; j++)
                a[i][j]=x.a[i][j];
    }

    void inversa(Matrice x)
    {
        Matrice inv(n);
        ///inv=1/det*A_stelat;
        int d=x.det();
        int c=1/d;
        x.A_stelat();
        inv=x&c;
    }
};

///Definirea operatorului de citire: scriem instructiunile
istream& operator >>(istream &in, Matrice &x)
{
    in >> x.n;
    x.a = new int *[x.n];
    for(int i=0; i<x.n; i++)
    {
        x.a[i] = new int[x.n];
        for(int j=0; j<x.n; j++)
            in >> x.a[i][j];
    }
    return in;
}

void meniu()
{
    int n1,n2,ef,mat,nr;
    cout<<"Cititi prima matrice(intai cititi n si dupa matricea) \n ";
    Matrice mat1;
    cin>>mat1;
    cout<<"Cititi a doua matrice(intai cititi n si dupa matricea) \n";
    Matrice mat2;
    cin>>mat2;
    while(ef!=0)
    {
        cout<<"______________________________________________________________\n";
        cout<<"Ce operatie doriti sa faceti?                                 |\n";
        cout<<"Cititi tasta 1 pentru adunarea celor doua matrici             |\n";
        cout<<"Cititi tasta 2 pentru scaderea celor doua matrici             |\n";
        cout<<"Cititi tasta 3 pentru inmultirea celor doua matrici           |\n";
        cout<<"Cititi tasta 4 pentru inmultirea cu un scalar a matricei      |\n";
        cout<<"Cititi tasta 5 pentru a ridica matricea la putere             |\n";
        cout<<"Cititi tasta 6 pentru a afla determinantul matricei           |\n";
        cout<<"Cititi tasta 7 pentru a face transpusa matricei               |\n";
        cout<<"Daca nu mai doriti sa faceti nici o operatie apasati tasta 0  |\n";
        cout<<"______________________________________________________________|\n";

        cin>>ef;
        if(ef==1)
        {
            Matrice h;
            h=mat1+mat2;
            h.afis();
        }

        if(ef==2)
        {
            Matrice h;
            h=mat1-mat2;
            h.afis();
        }

        if(ef==3)
        {
            Matrice h;
            h=mat1*mat2;
            h.afis();
        }

        if(ef==4)
        {
            cout<<"______________________________________________________________\n";
            cout<<"Pe care matrice vreti sa o inmultiti si cu cat?               |\n";
            cout<<"______________________________________________________________|\n";
            cin>>mat>>nr;
            if(mat==1)
            {
                Matrice h;
                h=mat1&nr;
                h.afis();
            }
            else
            {
                Matrice h;
                h=mat2&nr;
                h.afis();
            }

        }

        if(ef==5)
        {
            cout<<"______________________________________________________________\n";
            cout<<"Pe care matrice vreti sa o ridicati la putere si la ce putere?|\n";
            cout<<"______________________________________________________________|\n";
            cin>>mat;
            if(mat==1)
            {
                Matrice h;
                h=mat1^nr;
                h.afis();
            }
            else
            {
                Matrice h;
                h=mat2^nr;
                h.afis();
            }
        }
        if(ef==6)
        {
            cout<<"______________________________________________________________\n";
            cout<<"Carei matrice vreti sa ii faceti determinantul?               |\n";
            cout<<"______________________________________________________________|\n";
            cin>>mat;
            if(mat==1)
            {
                int r=mat1.det();
                cout<<r<<endl;
            }
            if(mat==2)
            {
                int r=mat2.det();
                cout<<r<<endl;
            }
        }
        if(ef==7)
        {
            cout<<"______________________________________________________________\n";
            cout<<"Carei matrice vreti sa ii faceti transpusa?                   |\n";
            cout<<"______________________________________________________________|\n";
            cin>>mat;
            if(mat==1)
            {
                Matrice h;
                h=mat1;
                h.transpusa();
                h.afis();
            }
            if(mat==2)
            {
                Matrice h;
                h=mat2;
                h.transpusa();
                h.afis();
            }
        }
    }

}

int main()
{
    ///Declarare matrice cu ** si citirea ei
    /*int n;
    double **a;
    cin>>n;
    a=new double *[n];
    for(int i=0;i<n;i++)
    {
        a[i]=new double[n];
        for(int j=0;j<n;j++)
            cin>>a[i][j];
    }
    */
    meniu();

    return 0;
}
