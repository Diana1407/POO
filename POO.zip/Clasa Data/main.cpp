#include <iostream>
#include <string.h>
#include <fstream>
#include <stdexcept>
#include <vector>

using namespace std;

int nrz[13];
ofstream g("date.out");

class Data
{
private:
    int zi,luna,an;
public:
    ///Constrcuto implicit
    Data () {};
    ///Constructor de initializare
    Data(int ziua,int lunaa,int anul)
    {
        zi=ziua;
        luna=lunaa;
        an=anul;
    }

    ///Functie de verificare a erorilor (if... throw out_of_range)
    void verif()
    {
        if(luna>12)
            throw out_of_range("Luna inexistenta");
        if(an>2019 && an<1900)
            throw out_of_range("An in afara intervalului");
        if((luna==1 || luna==3 || luna==5 || luna==7 || luna==8 || luna==10|| luna==12) && zi>31)
            throw out_of_range("Nu are sens");
        if((luna==4 || luna==6 || luna==9 || luna==11) && zi>30)
            throw out_of_range("Nu are sens");
    }

    void set_zi(int ziua)
    {
        zi=ziua;
    }
    void set_luna(int lunaa)
    {
        luna=lunaa;
    }
    void set_an(int anul)
    {
        an=anul;
    }

    int get_zi()
    {
        return zi;
    }
    int get_luna()
    {
        return luna;
    }
    int get_an()
    {
        return an;
    }

    void print()
    {
        g<<zi<<"."<<luna<<"."<<an<<endl;
    }

    void transf_data(char date[])
    {
        //if(strchr(date,'/')!=0)
            //throw out_of_range("Data incorecta");
        char v[101][101];
        int k=0;
        char *p=strtok(date,".:");
        while(p)
        {
            strcpy(v[k++],p);
            p=strtok(NULL,".:");
        }
        ///Transfor char in numar
        for(int i=0; i<k; i++)
        {
            int nr=0;
            int j=0;
            while(j<strlen(v[i]) && (v[i][j]>=48 && v[i][j]<58))
            {
                int a=(int)v[i][j]-48;
                nr=nr*10+a;
                j++;
            }
            if(i==0)
                set_zi(nr);
            if(i==1)
                set_luna(nr);
            if(i==2)
                set_an(nr);
        }
    }

    ///Compararea se face pe numere nu cronologic
    ///deci rezultatul e opus la ceea ce intreb
    bool operator ==(Data X)
    {
        return (zi==X.zi) && (luna==X.luna) && (an==X.an);
    }

    bool operator !=(Data X)
    {
        return (zi!=X.zi) || (luna!=X.luna) || (an!=X.an);
    }

    bool operator >(Data X)
    {
        return (an>X.an) || (an==X.an && luna>X.luna) || (an==X.an && luna==X.luna && zi>X.zi);
    }

    bool operator <(Data X)
    {
        return (an<X.an) || (an==X.an && luna<X.luna) || (an==X.an && luna==X.luna && zi<X.zi);
    }

    ///Initializez vectorul de luni
    void nr_zile()
    {
        for(int i=1; i<=12; i++)
        {
            if(i==1 || i==3 || i==5 || i==7 || i==8 || i==10|| i==12)
                nrz[i]=31;
            if(i==2)
                nrz[i]=28;
            if(i==4 || i==6 || i==9 || i==11)
                nrz[i]=30;
        }
    }

    Data operator =(Data X)
    {
        zi=X.zi;
        luna=X.luna;
        an=X.an;
        return *this;
    }

    bool bisect(int x)
    {
        if(x%400==0)
            return true;
        return false;
    }

    ///Face diferenta intre doua date calendaristice
    int operator - (Data &X)
    {
        nr_zile();
        if(bisect(an))
            nrz[2]=29;

        ///La zile se pune +1
        ///Daca luna si anul sunt la fel scad zilele
        if(an==X.an&&luna==X.luna)
            return X.zi-zi+1;

        ///Daca doar anul e la fel scad lunile intregi si dupa zilele
        if(an==X.an)
        {
            int total=nrz[luna]-zi+1;
            for(int i=luna+1; i<=X.luna-1; i++)
                total+=nrz[i];
            total+=X.zi;
            return total;
        }

        ///Daca totul e diferit scad anii intregi apoi lunile intregi si dupa zilele
        ///Sa fiu atenta la an bisect(da +366 nu +365)
        int total=nrz[luna]-zi+1;
        for(int i=luna+1; i<=12; i++)
            total+=nrz[i];

        for(int i=an+1; i<=X.an-1; i++)
            if(bisect(i))
                total+=366;
            else
                total+=365;

        if(bisect(X.an))
            nrz[2]=29;
        else
            nrz[2]=28;
        for(int i=1; i<=X.luna-1; i++)
            total+=nrz[i];

        total+=X.zi;
        return total;
    }
};

int main()
{
    char fis[256];
    cin>>fis;
    ifstream f(fis);
    ///Se creeaza fis de iesire
    char *p=strtok(fis,".");
    //strcat(p,".out");
    //ofstream g(p);
    Data indepartata(1,1,2019);
    Data recenta(1,1,1899);
    Data v[101],x;
    int n,k=0;
    char s[256];
    f>>n;
    for(int i=0; i<n; i++)
    {
        f>>s;
        try
        {
            x.transf_data(s);
            x.verif();
        }
        catch(exception &e)
        {
            ///Numaratoarea pleaca 0
            g<<"Eroare: "<<e.what()<<" la data introdusa cu nr: "<<i+1<<endl;
            continue;
        }
        v[k++]=x;
        if(x>recenta)
            recenta=x;
        if(x<indepartata)
            indepartata=x;
    }
    for(int i=0;i<k;i++)
    {
        for(int j=i+1;j<k;j++)
            if(v[i]>v[j])
            swap(v[i],v[j]);
    }
    g<<"Datele ordonate in ordine cronologica:"<<endl;
    for(int i=0;i<k;i++)
        v[i].print();
    g<<"Cea mai recenta data este: "<<endl;
    recenta.print();
    g<<"Cea mai indepartata data este: "<<endl;
    indepartata.print();
    int dif;
    ///Diferenta se face intre indeparta-recenta
    dif=indepartata-recenta;
    g<<"Diferenta dintre cele mai indepartate date este: "<<dif<<" de zile"<<endl;
    return 0;
}
