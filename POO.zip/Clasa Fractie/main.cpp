#include <iostream>
#include <stdlib.h>

using namespace std;

class Fractie
{
private:
    int numarator, numitor;
public:
    ///Constructor implicit
    Fractie() {};
    ///Constructor de initializare
    Fractie(int numa, int numi)
    {
        numarator=numa;
        numitor=numi;
    };

    void print()
    {
        cout<<numarator<<"/"<<numitor<<endl;
    }

    void set_numarator(int numa)
    {
        numarator=numa;
    }
    void set_numitor(int numi)
    {
        numitor=numi;
    }
    int get_numarator()
    {
        return numarator;
    }
    int get_numitor()
    {
        return numitor;
    }

    ///Functie pentru simplificare
    void cmmdc()
    {
        int s;
        int a=numarator;
        int b=numitor;
        ///Sa fiu atenta sa verific cine e mai mare
        if(a>b)
        {
            while (b!=0)
            {
                int r=a%b;
                a=b;
                b=r;
            }
            s=a;
        }

        if(a<b)
        {
            while (a!=0)
            {
                int r=b%a;
                b=a;
                a=r;
            }
            s=b;
        }

        ///salvez in s cmmdc si ma intreb daca e dif de 1 pt ca altfel ar merge programul in gol
        if(s!=1)
            while(numarator%s==0 && numitor%s==0)
            {
                numarator/=s;
                numitor/=s;
            }
    }

    Fractie operator + (Fractie X)
    {
        ///Verific daca am numitor comun daca nu inmultesc numitorul la numaratorul fractiilor opuse
        Fractie result;
        if(numitor==X.numitor)
        {
            result.numarator=numarator+X.numarator;
            result.numitor=numitor;
        }
        else
        {
            result.numarator=numarator*X.numitor+X.numarator*numitor;
            result.numitor=numitor*X.numitor;
        }

        return result;
    }
    Fractie operator - (Fractie X)
    {
        ///Verific daca am numitor comun daca nu inmultesc numitorul la numaratorul fractiilor opuse
        Fractie result;
        if(numitor==X.numitor)
        {
            result.numarator=numarator-X.numarator;
            result.numitor=numitor;
        }
        else
        {
            result.numarator=numarator*X.numitor-X.numarator*numitor;
            result.numitor=numitor*X.numitor;
        }

        return result;
    }
    Fractie operator * (Fractie X)
    {
        Fractie result;
        result.numarator=numarator*X.numarator;
        result.numitor=numitor*X.numitor;
        return result;
    }
    Fractie operator / (Fractie X)
    {
        Fractie result;
        result.numarator=numarator*X.numitor;
        result.numitor=numitor*X.numarator;
        return result;
    }
    Fractie operator =( Fractie &X)
    {
        if(this != &X)
        {
            this->numarator=X.numarator;
            this->numitor=X.numitor;
        }
        return *this;
    }
    void operator !()
    {
        swap(numarator,numitor);
    }
    bool operator ==(Fractie X)
    {
        return (numarator==X.numarator) && (numitor==X.numitor);
    }
    bool operator !=(Fractie X)
    {
        return (numarator!=X.numarator) || (numitor==X.numitor);
    }
    ///Operatori de comparatie ii fac inmultind in cruce
    bool operator <(Fractie X)
    {
        return (numarator*X.numitor<X.numarator*numitor);
    }
    bool operator >(Fractie X)
    {
        return (numarator*X.numitor>X.numarator*numitor);
    }
    bool operator <=(Fractie X)
    {
        return (numarator*X.numitor<=X.numarator*numitor);
    }
    bool operator >=(Fractie X)
    {
        return (numarator*X.numitor>=X.numarator*numitor);
    }

};
int main()
{
    int ok=1;///presupunem ca a>b
    int numa,numi;
    cin>>numa>>numi;
    Fractie a(numa,numi);
    a.print();
    cin>>numa>>numi;
    Fractie b(numa,numi);
    b.print();
    ///Trebuie sa compar fractiile a si b si dupa sa fac diferenta
    Fractie dif1=a-b;
    Fractie dif2=b-a;
    Fractie dif;
    if(a>b)
        dif=dif1;
    else
        dif=dif2;
    dif.cmmdc();
    cout<<"Diferenta in modul este: ";
    dif.print();
    Fractie suma=a+b;
    suma.cmmdc();
    cout<<"Suma este: ";
    suma.print();
    Fractie prod=a*b;
    prod.cmmdc();
    cout<<"Produsul este: ";
    prod.print();
    cout<<"Inversa este: ";
    !prod;
    prod.print();
    /*int numa,numi;
    cin>>numa>>numi;
    Fractie a(numa,numi),b;
    a.print();
    cin>>numa>>numi;
    b.set_numarator(numa);
    b.set_numitor(numi);
    b.print();
    Fractie c=a+b;
    c.print();
    Fractie d=a-b;
    d.print();
    Fractie e=a*b;
    e.print();
    Fractie f=a/b;
    f.print();
    Fractie g;
    g=a;
    g.print();
    g.cmmdc();
    !g;
    g.print();
    */
    return 0;
}
