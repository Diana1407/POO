#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>
using namespace std;

ifstream fin ("stiva.in");
ofstream fout ("stiva.out");

///template=poate sa isi schimbe "tipul"
template <class T >

class stiva
{
private:
    vector < T > s;
public :
    stiva(){}
    ///Constructor de initializare cu parametru stiva
    stiva(const stiva&a)
    {
        for (auto j : a.s)
            s.push_back(j);
    }
    ///Constructor de initializare cu parametru un vector
    stiva(vector < int > b)
    {
        for (auto j : b)
            s.push_back(j);
    }

    ~stiva()
    {
        s.clear();
    }

    int top()
    {
        if (s.size() > 0)
            return s.back();///ultima valoare din stiva a
    }
    void pop()
    {
        if (s.size() > 0)
            s.pop_back();///sterge val din varful st
    }

    void push(T x)
    {
        s.push_back(x);
    }

    bool isEmpty()
    {
        if (s.size() == 0)
            return true;
        return false;
    }

};

char s[100001];
stiva<int>nr;
stiva<char>operatori;

///Calculez gradul rezolvarii
int grad(char t)
{
    if ( t == '+' or t == '-')
        return 1;
    if ( t == '*' or t == '/')
        return 2;
    return 0;
}

///calculez pt orice semn doar ca nu calculez prioritatea
void calcul()
{

    while(!operatori.isEmpty() and operatori.top()!= '(')
    {
        char op = operatori.top();
        operatori.pop();
        int nr1 = nr.top();
        nr.pop();
        int nr2 = nr.top();
        nr.pop();
        if(op == '+')
            nr.push(nr1+nr2);
        else if (op == '-')
            nr.push(nr2-nr1);
        else if(op =='*')
            nr.push(nr1*nr2);
        else if(op =='/')
            nr.push(nr1/nr2);

    }
    if(!operatori.isEmpty())///daca nu e vida
        operatori.pop();
}

///aici calculez pt orice semn si verific prioritatea
void calculprioritate(char s)
{
    while(!operatori.isEmpty() and grad(operatori.top()) >= grad(s))
    {
        char op = operatori.top();
        operatori.pop();
        int nr1 = nr.top();
        nr.pop();
        int nr2 = nr.top();
        nr.pop();
        if(op == '+')
            nr.push(nr1+nr2);
        else if (op == '-')
            nr.push(nr2-nr1);
        else if(op =='*')
            nr.push(nr1*nr2);
        else if(op =='/')
            nr.push(nr1/nr2);
    }
}

int main()
{
    ///Citesc o ecuatie si o parcurg
    fin.getline(s,100001);
    int n = strlen(s);
    ///Verific ce este fiecare caracter:
    ///1.daca e spatiu dau continue
    ///2.daca e cifra transform in numar
    ///3.daca e paranteza deschisa: merg mai departe si caut pana dau de cea inchisa si dupa apelez calcul
    ///4.daca e semn apelez calculcuprioritate
    for ( int i = 0 ; i < n; ++i)
    {
        if(s[i] == ' ')
            continue;
        if (s[i] == '(')
            operatori.push(s[i]);
        else if (s[i] == '+' or s[i] == '-' or s[i] == '*' or s[i] =='/')
        {
            calculprioritate(s[i]);
            operatori.push(s[i]);

        }
        else if(s[i] == ')')
            calcul();
        else if(s[i] >= '0' and s[i] <= '9')
        {
            int val = 0;
            while (s[i] >= '0' and s[i] <= '9' and i < n)
            {
                val = val*10 + s[i]-'0';
                i++;
            }
            i--;
            nr.push(val);
        }

    }

    ///se mai calculeaa o data daca a ramas ceva (raman doar semne de + sau -)
    while(!operatori.isEmpty())
    {
        char op = operatori.top();
        operatori.pop();
        int nr1 = nr.top();
        nr.pop();
        int nr2 = nr.top();
        nr.pop();

        if(op == '+')
            nr.push(nr1+nr2);
        else if (op == '-')
            nr.push(nr2-nr1);

    }
    fout << nr.top();
    return 0;
}
