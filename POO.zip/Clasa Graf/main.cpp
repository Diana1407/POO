#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
#include <stack>
#include <algorithm>

using namespace std;

ifstream f("graf.in");
ofstream fout("graf.out");

class Graf
{
private:
    int n,m,cnt=1;
    int viz[101],d[101];
    vector <pair<int,double>>G[101];
    vector<vector<int>>ctc;
    stack<int>st;

public:
    ///Constructor implicit
    Graf()
    {
        n=0;
        m=0;
    }
    ///Constructor de initializare
    Graf(int nn, int mm)
    {
        n=nn;
        m=mm;
    }
    ///Destructor care goleste graful
    ~Graf()
    {
        for(int i=1; i<=n; i++)
            G[i].clear();
        n=0;
        m=0;
    }
    void addEdge(int startNode, int endNode, double cost)
    {
        ///aflu cate noduri sunt comparand n actual cu maxim dintre nodul de start si de end
        n=max(n,max(startNode,endNode));
        ///ok e 0 presupunem ca nu avem muchia si o putem adauga
        int ok=0;
        ///cautam daca exista deja muchia
        for(auto &x:G[startNode])
            if(x.first==endNode && x.second==cost)
                ok=1;
        if(ok==0)
        {
            G[startNode].push_back({endNode,cost});
            m++;
        }
    }

    int get_n()
    {
        return n;
    }
    int get_m()
    {
        return m;
    }
    int get_cnt()
    {
        return cnt;
    }

    vector <double>Dijkstra(int startNode)
    {
        ///alg dijkstra cu priority queue
        ///vectorul de drumuri e declarat cu vector<int>
        static double inf=1239.945;
        vector <double>d;
        d=vector<double>(n+1);
        for (auto &x:d)
            x=inf;
        d[startNode]=0;
        ///Nu mai fac struct pt comare ci compar direct in priority
        priority_queue<pair<double,int>,vector<pair<double,int>>,greater<pair<double,int>>>Q;
        Q.push({0,startNode});
        while(!Q.empty())
        {
            int nod=Q.top().second;
            int cost=Q.top().first;
            for(auto &x:G[nod])
                if(d[x.first]>d[nod]+x.second)
                {
                    d[x.first]=d[nod]+x.second;
                    Q.push({d[x.first],x.first});
                }
            Q.pop();
        }
        for (int i=1; i<=n; i++)
            cout<<d[i]<<" ";
        return d;
    }

    ///Agoritmul Kosaraju
    void dfs(int nod)
    {
        viz[nod]=1;
        for(auto &x:G[nod])
            if(viz[x.first]==0)
                dfs(x.first);
        st.push(nod);
    }
    void dfstranspusa(int nod)
    {
        viz[nod]=1;
        ctc[cnt].push_back(nod);
        fout<<nod<<" ";
        for(auto &x:G[nod])
            if(viz[x.first]==0)
                dfstranspusa(x.first);
    }
    void kosaraju()
    {
        for(int i=1; i<=n; i++)
            if(viz[i]==0)
                dfs(i);
        for(int i=1; i<=n; i++)
            viz[i]=0;
        while(!st.empty())
        {
            int nod=st.top();
            st.pop();
            if(viz[nod]==0)
            {
                fout<<"Componenta numarul "<<cnt<<" are nodurile: ";
                dfstranspusa(nod);
                cnt++;
                fout<<endl;
            }
        }
    }
    vector<vector<int>>stronglyConnectedComponents()
    {
        ctc=vector<vector<int>>(n-1);
        kosaraju();
        for(int i=1; i<=cnt; i++)
            sort(ctc[cnt].begin(),ctc[cnt].end());
        return ctc;
    }

    void print()
    {
        cout<<n<<" "<<m<<endl;
        for(int i=1; i<=n; i++)
            for(auto &x:G[i])
                cout<<i<<" "<<x.first<<" "<<x.second<<endl;
    }
};

int main()
{
    int st;
    Graf g;
    int x,y;
    double c;
    while(f>>x>>y>>c)
    {
        g.addEdge(x,y,c);
    }
    g.print();
    cout<<"Citit nodul de start: ";
    cin>>st;
    g.Dijkstra(st);
    vector<vector<int>>vec_comp=g.stronglyConnectedComponents();
    g.stronglyConnectedComponents();
    int nr_comp=g.get_cnt();
//    for(int i=1;i<=nr_comp;i++)
//    {
//        fout<<"componenta "<<i<<" are";
//        for(auto &x:vec_comp[i])
//            fout<<x<<" ";
//        fout<<endl;
//    }
    return 0;
}
