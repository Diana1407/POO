#include <iostream>
#include <fstream>
#include <math.h>
#include <string.h>
#define pi 3.14

using namespace std;

ifstream f("fig_geom.in");

///Afisez ce am apletal pentru constructori
ofstream g("fig_geom.out");

///Afisez ce am apelat pentru metode Arie si Afis
///Arie va aparea de mai multe ori pt ca se apeleaza de doua ori: la sortare si la afisare
ofstream fout("arie.out");

///Metodele virtual se declara public
///Figura Geometrica nu are nimic private
class Figura_Geometrica
{
public:

    virtual double Perimetru()=0;
    virtual double Arie()=0;
    virtual void Afis()=0;
    Figura_Geometrica()
    {
        g<<"Apelat constructorul clasei figuraGeometrica\n";
    };
};

class Triunghi:public Figura_Geometrica
{
private:
    double lat1,lat2,lat3;
public:
    Triunghi()
    {
        g<<"A fost apelat constructorul implicit al clasei Triunghi\n";
        lat1=0;
        lat2=0;
        lat3=0;
    }
    Triunghi(double a,double b,double c)
    {
        g<<"A fost apelat constructorul de initializare al clasei Triunghi\n";
        lat1=a;
        lat2=b;
        lat3=c;
    }
    double Perimetru()
    {
        return lat1+lat2+lat3;
    }
    ///Aria e cu formula lui heron Semiperimetru*Semiperimetru-fiecare lat pe rand
    double Arie()
    {
        fout<<"A fost apelata metoda pentru arie pentru clasa Triunghi\n";
        double semiperimetru=(lat1+lat2+lat3)/2;
        double arie=sqrt(semiperimetru*(semiperimetru-lat1)*(semiperimetru-lat2)*(semiperimetru-lat3));
        return arie;
    }
    void Afis()
    {
        fout<<"A fost apelata metoda afis pentru clasa Triunghi\n";
        cout<<"Triunghi ";
    }
};

class Triunghi_Dreptunghic: public Triunghi
{
private:
    double lat1,lat2,lat3;
public:
    Triunghi_Dreptunghic()
    {
        g<<"A fost apelat constructor implicit al clasei Triunghi Dreptunghic \n";
        lat1=0;
        lat2=0;
        lat3=0;
    }
    Triunghi_Dreptunghic(double a, double b, double c)
    {
        g<<"A fost apelat constructor de initalizare al clasei Triunghi Dreptunghic \n";
        lat1=a;
        lat2=b;
        lat3=c;
    }
    double Perimetru()
    {
        return lat1+lat2+lat3;
    }
    double Arie()
    {
        fout<<"A fost apelata metoda pentru arie pentru clasa Triunghi Dreptunghic\n ";
        ///Calculam aria verificand care sunt catetele si dupa folosim formula c1*c2/2
        if(lat1*lat1==lat2*lat2+lat3*lat3)
            return (lat2*lat3)/2;
        if(lat2*lat2==lat1*lat1+lat3*lat3)
            return (lat1*lat3)/2;
        if(lat3*lat3==lat1*lat1+lat2*lat2)
            return (lat1*lat2)/2;
    }
    void Afis()
    {
        fout<<"A fost apelata metoda afis pentru clasa Triunghi Dreptunghic\n";
        cout<<"Triunghi Dreptunghic ";
    }

};

class Triunghi_Echilateral: public Triunghi
{
private:
    double lat;
public:
    Triunghi_Echilateral()
    {
        g<<"A fost apelat constructorul implicit al clasei Triunghi Echilateral\n";
        lat=0;
    }
    Triunghi_Echilateral(double a)
    {
        g<<"A fost apelat constructor de initalizare al clasei Triunghi Echilateral \n";
        lat=a;
    }
    double Perimetru()
    {
        return 3*lat;
    }
    double Arie()
    {
        fout<<"A fost apelata metoda pentru arie pentru clasa Triunghi Echilateral\n";
        return ((lat*lat)*sqrt(3))/4;
    }
    void Afis()
    {
        fout<<"A fost apelata metoda afis pentru clasa Triunghi Echilateral\n";
        cout<<"Triunghi Echilateral ";
    }
};

///Clasa Patrulater nu are nimic
class Patrulater :public Figura_Geometrica
{
public:
    Patrulater()
    {
        g<<"A fost apelat constructorul implicit al clasei Patrulater\n";
    }
};

class Dreptunghi : public Patrulater
{
private:
    double L,l;
public:
    Dreptunghi()
    {
        g<<"A fost apelat constructorul implicit al clasei Dreptunghi\n";
        L=0;
        l=0;
    }
    Dreptunghi (double lungime, double latime)
    {
        g<<"A fost apelat constructorul de initializare al clasei Dreptunghi\n";
        L=lungime;
        l=latime;
    }
    double Perimetru()
    {
        return 2*L+2*l;
    }
    double Arie()
    {
        fout<<"A fost apelata metoda pentru arie pentru clasa Dreptunghi\n";
        return L*l;
    }
    void Afis()
    {
        fout<<"A fost apelata metoda afis pentru clasa Dreptunghi\n";
        cout<<"Dreptunghi ";
    }
};

class Patrat: public Patrulater
{
private:
    double l;
public:
    Patrat()
    {
        g<<"A fost apelat constructorul implicit al clasei Patrat \n";
        l=0;
    }
    Patrat(double lat)
    {
        g<<"A fost apelat constructorul de initializare al clasei Patrat \n";
        l=lat;
    }
    double Perimetru()
    {
        return 4*l;
    }
    double Arie()
    {
        fout<<"A fost apelata metoda pentru arie pentru clasa Patrat \n";
        return l*l;
    }
    void Afis()
    {
        fout<<"A fost apelata metoda afis pentru clasa Patrat \n";
        cout<<"Patrat ";
    }
};


class Cerc: public Figura_Geometrica
{
private:
    double r;
public:
    Cerc()
    {
        g<<"A fost apelat constructorul implicit al clasei Cerc\n";
        r=0;
    }
    Cerc(double raza)
    {
        g<<"A fost apelat constructorul de initializare al clasei Cerc\n";
        r=raza;
    }
    double Perimetru()
    {
        return 2*r*pi;
    }
    double Arie()
    {
        fout<<"A fost apelata metoda pentru arie pentru clasa Cerc\n";
        return pi*(r*r);
    }
    void Afis()
    {
        fout<<"A fost apelata metoda afis pentru clasa Cerc\n";
        cout<<"Cerc ";
    }

};

void cit()
{
    ///Fac un vector de tipul Figura Geometrica ** pt a salva toate figurile citite
    int n;
    char s[256];
    Figura_Geometrica **vec=new Figura_Geometrica*[200];
    f>>n;
    f.get();
    for(int i=0;i<n;i++)
    {
        f.getline(s,256);
        if(strcmp(s,"Triunghi")==0)
        {
            double l1,l2,l3;
            cout<<"Triunghi: Cititi lungimile pentru cele 3 laturi: ";
            cin>>l1>>l2>>l3;
            vec[i]=new Triunghi(l1,l2,l3);
            continue;
        }
        if(strcmp(s,"TriunghiDreptunghic")==0)
        {
            double l1,l2,l3;
            cout<<"Triunghi Dreptunghic: Cititi lungimile pentru cele 3 laturi: ";
            cin>>l1>>l2>>l3;
            vec[i]=new Triunghi_Dreptunghic(l1,l2,l3);
            continue;
        }
        if(strcmp(s,"TriunghiEchilateral")==0)
        {
            double l;
            cout<<"Triunghi Echilateral: Cititi lumgimea pentru latura: ";
            cin>>l;
            vec[i]=new Triunghi_Echilateral(l);
            continue;
        }
        if(strcmp(s,"Dreptunghi")==0)
        {
            double L,l;
            cout<<"Dreptunghi: Cititi Lungime si latimea: ";
            cin>>L>>l;
            vec[i]=new Dreptunghi(L,l);
            continue;
        }
        if(strcmp(s,"Patrat")==0)
        {
            double l;
            cout<<"Patrat: Cititi lungimea pentru latura: ";
            cin>>l;
            vec[i]=new Patrat(l);
            continue;
        }

        if(strcmp(s,"Cerc")==0)
        {
            double r;
            cout<<"Cerc: Cititi raza cercului: ";
            cin>>r;
            vec[i]=new Cerc(r);
            continue;
        }
    }
    cout<<"\n\n";
    ///Compar ariile figurilor citite folosind -> si la afis tot cu ->(pt ca vectorul e pointer)
    for(int i=0;i<n-1;i++)
        for(int j=i+1;j<n;j++)
        {
            if(vec[i]->Arie()>vec[j]->Arie())
                swap(vec[i],vec[j]);
        }
    for(int i=0;i<n;i++)
    {
        vec[i]->Afis();
        cout<<vec[i]->Arie()<<"\n";
    }
}

int main()
{
    cit();
    return 0;
}
